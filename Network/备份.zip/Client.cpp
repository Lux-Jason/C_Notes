﻿//Client.cpp
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include "DES_c.h" 
#pragma comment(lib, "ws2_32.lib")

constexpr int DEFAULT_PORT = 5000;
constexpr int BUFFER_SIZE = 1024;
std::atomic<bool> isRunning(true);

// 客户端状态信息
struct ClientState {
    std::string username;
    std::vector<std::string> joinedGroups;
    std::vector<std::string> ownedGroups; // 添加用户创建的组列表
} clientState;

void PrintHelp() {
    std::cout << "\n可用命令：\n"
        << "/login <用户名>        - 登录/更改昵称\n"
        << "/create <群组名>       - 创建新群组\n" // 添加创建群组命令
        << "/kick <群组名> <用户名> - 群主踢人\n"
        << "/disband <群组名>       - 群主解散群组\n"
        << "/mute <群组名> <用户名> - 群主禁言群成员\n"
        << "/unmute <群组名> <用户名> - 群主解除禁言\n"
        << "/join <群组名>         - 加入群组\n"
        << "/leave <群组名>        - 离开群组\n"
        << "/members <群组名>     - 查看群组成员\n"
        << "/muted <群组名>       - 查看禁言用户\n"
        << "/list                 - 列出在线用户\n"
        << "/listgroups           - 列出所有可用群组\n" // 添加列出群组命令
        << "/private <用户> <消息> - 私聊消息\n"
        << "/group <群组> <消息>   - 群组消息\n"
        << "/public <消息>         - 广播消息\n"
        << "/exit                 - 退出程序\n"
        << "/help                 - 显示帮助\n";
}

// -------- 客户端接收线程：支持长度头 + DES 解包 --------
void MessageReceiver(SOCKET sock)
{
    std::vector<char> inBuf;               // 原始收包缓冲区
    std::vector<char> plainBuf;            // 解密后明文
    char tmp[BUFFER_SIZE];

    auto needMore = [&](void) -> bool {
        int n = recv(sock, tmp, BUFFER_SIZE, 0);
        if (n <= 0) {
            if (n == SOCKET_ERROR)
                std::cerr << "\n接收错误: " << WSAGetLastError() << std::endl;
            isRunning = false;
            return false;                  // 连接关闭
        }
        inBuf.insert(inBuf.end(), tmp, tmp + n);
        return true;
        };

    while (isRunning)
    {
        /*------------------- ① 解析 4 字节明文长度头 -------------------*/
        while (inBuf.size() < 4 && needMore()) {}
        if (inBuf.size() < 4) break;       // 断线

        uint32_t L;
        memcpy(&L, inBuf.data(), 4);
        L = ntohl(L);                      // 明文长度

        /*------------------- ② 计算需要的加密字节数 -------------------*/
        size_t pad = 8 - (L % 8);
        if (pad == 0) pad = 8;
        size_t encLen = L + pad;           // 密文总长度

        /*------------------- ③ 收满整条密文 -------------------*/
        while (inBuf.size() < 4 + encLen && needMore()) {}
        if (inBuf.size() < 4 + encLen) break;   // 断线

        /*------------------- ④ 解密整条消息 -------------------*/
        plainBuf.clear();
        for (size_t off = 4; off < 4 + encLen; off += 8) {
            char blk[8];
            memcpy(blk, inBuf.data() + off, 8);
            des_decrypt(blk);
            plainBuf.insert(plainBuf.end(), blk, blk + 8);
        }
        inBuf.erase(inBuf.begin(), inBuf.begin() + 4 + encLen); // 移除已处理字节

        /*------------------- ⑤ 去除 PKCS#7 填充 -------------------*/
        if (plainBuf.empty()) continue;    // 防御性检查
        size_t realLen = plainBuf.size() - static_cast<unsigned char>(plainBuf.back());
        if (realLen > plainBuf.size()) continue; // 填充异常，忽略
        std::string msg(plainBuf.data(), realLen);

        /*------------------- ⑥ 解析 "TYPE|FROM|CONTENT" 协议 -------------------*/
        size_t p1 = msg.find('|');
        size_t p2 = msg.find('|', p1 + 1);
        if (p1 == std::string::npos || p2 == std::string::npos) continue;

        std::string type = msg.substr(0, p1);
        std::string from = msg.substr(p1 + 1, p2 - p1 - 1);
        std::string content = msg.substr(p2 + 1);

        if (type == "PRIVATE") {
            std::cout << "\n[私聊来自 " << from << "]: " << content << std::endl;
        }
        else if (type == "GROUP") {
            size_t separator = content.find('|');
            if (separator != std::string::npos) {
                std::string sender = content.substr(0, separator);
                std::string message = content.substr(separator + 1);
                std::cout << "\n[群组 " << from << " 来自 " << sender << "]: " << message << std::endl;
            }
        }
        else if (type == "PUBLIC") {
            std::cout << "\n[广播来自 " << from << "]: " << content << std::endl;
        }
        else if (type == "USERS") {
            std::replace(content.begin(), content.end(), ',', '\n');
            std::cout << "\n在线用户列表:\n" << content << std::endl;
        }
        else if (type == "GROUPS") {
            std::replace(content.begin(), content.end(), ',', '\n');
            std::cout << "\n可用群组列表:\n" << content << std::endl;
        }
        else if (type == "LOGIN") {
            std::cout << "\n[登录成功]: " << content << std::endl;
            clientState.username = content;
        }
        else if (type == "CREATE") {
            std::cout << "\n[创建群组成功]: " << content << std::endl;
            clientState.ownedGroups.push_back(content);
            clientState.joinedGroups.push_back(content);
        }
        else if (type == "JOIN") {
            std::cout << "\n[加入群组成功]: " << content << std::endl;
            if (std::find(clientState.joinedGroups.begin(),
                clientState.joinedGroups.end(), content) == clientState.joinedGroups.end()) {
                clientState.joinedGroups.push_back(content);
            }
        }
        else if (type == "LEAVE") {
            std::cout << "\n[离开群组成功]: " << content << std::endl;
            auto it = std::find(clientState.joinedGroups.begin(),
                clientState.joinedGroups.end(), content);
            if (it != clientState.joinedGroups.end()) {
                clientState.joinedGroups.erase(it);
            }
            auto it2 = std::find(clientState.ownedGroups.begin(),
                clientState.ownedGroups.end(), content);
            if (it2 != clientState.ownedGroups.end()) {
                clientState.ownedGroups.erase(it2);
            }
        }
        else if (type == "SYS") {
            std::cout << "\n[系统消息]: " << content << std::endl;
        }
        else if (type == "MUTED") {
            std::cout << "\n[群组 " << from << " 的禁言成员]:\n" << content << std::endl;
        }

        std::cout << "输入命令 (?查看帮助): ";
        std::cout.flush();
    }
}

void SendMessage(SOCKET sock, const std::string& msg) {
    // --- 1. PKCS#7 填充 ---
    size_t pad = 8 - (msg.size() % 8);
    if (pad == 0) pad = 8;
    std::string padded = msg + std::string(pad, static_cast<char>(pad));

    // --- 2. 加密 ---
    std::vector<char> enc;
    enc.reserve(padded.size());
    for (size_t i = 0; i < padded.size(); i += 8) {
        char blk[8]; memcpy(blk, padded.data() + i, 8);
        des_encrypt(blk);
        enc.insert(enc.end(), blk, blk + 8);
    }

    // --- 3. 带 4 字节长度头发送 ---
    uint32_t L = htonl(static_cast<uint32_t>(msg.size()));  // 明文长度
    send(sock, reinterpret_cast<char*>(&L), 4, 0);
    send(sock, enc.data(), static_cast<int>(enc.size()), 0);
}

void HandleInput(SOCKET sock) {
    std::string input;
    PrintHelp();

    while (isRunning) {
        std::cout << "输入命令 (?查看帮助): ";
        std::getline(std::cin, input);

        if (input.empty()) continue;

        if (input[0] == '/') {
            size_t space = input.find(' ');
            std::string cmd = input.substr(1, space - 1);
            std::string args = (space != std::string::npos) ? input.substr(space + 1) : "";

            if (cmd == "login") {
                if (!args.empty()) {
                    SendMessage(sock, "LOGIN|" + args + "|-");
                }
                else {
                    std::cout << "[错误]: 请提供用户名，例如: /login username" << std::endl;
                }
            }
            else if (cmd == "create") {
                if (!args.empty()) {
                    SendMessage(sock, "CREATE|" + args + "|-");
                }
                else {
                    std::cout << "[错误]: 请提供群组名，例如: /create groupname" << std::endl;
                }
            }
            else if (cmd == "kick") {
                // 解析群组名和用户名
                size_t split = args.find(' ');
                if (split != std::string::npos) {
                    std::string group = args.substr(0, split);
                    std::string user = args.substr(split + 1);

                    // 检查当前用户是否为群主
                    if (std::find(clientState.ownedGroups.begin(),
                        clientState.ownedGroups.end(), group) != clientState.ownedGroups.end()) {
                        SendMessage(sock, "KICK|" + group + "|" + user);
                    }
                    else {
                        std::cout << "[错误]: 您不是群主，无法踢人" << std::endl;
                    }
                }
                else {
                    std::cout << "[错误]: 请正确提供群组名和用户名，例如: /kick groupname username" << std::endl;
                }
            }
            else if (cmd == "disband") {
                if (!args.empty()) {
                    // 检查当前用户是否为群主
                    if (std::find(clientState.ownedGroups.begin(),
                        clientState.ownedGroups.end(), args) != clientState.ownedGroups.end()) {
                        SendMessage(sock, "DISBAND|" + args + "|-");

                        // 本地清除群组信息
                        auto it1 = std::find(clientState.ownedGroups.begin(),
                            clientState.ownedGroups.end(), args);
                        if (it1 != clientState.ownedGroups.end())
                            clientState.ownedGroups.erase(it1);

                        auto it2 = std::find(clientState.joinedGroups.begin(),
                            clientState.joinedGroups.end(), args);
                        if (it2 != clientState.joinedGroups.end())
                            clientState.joinedGroups.erase(it2);
                    }
                    else {
                        std::cout << "[错误]: 您不是群主，无法解散群组" << std::endl;
                    }
                }
                else {
                    std::cout << "[错误]: 请提供群组名，例如: /disband groupname" << std::endl;
                }
            }
            else if (cmd == "mute") {
                size_t split = args.find(' ');
                if (split != std::string::npos) {
                    std::string group = args.substr(0, split);
                    std::string user = args.substr(split + 1);
                    SendMessage(sock, "MUTE|" + group + "|" + user);
                }
                else {
                    std::cout << "[错误]: /mute 群组 用户名\n";
                }
            }
            else if (cmd == "unmute") {
                size_t split = args.find(' ');
                if (split != std::string::npos) {
                    std::string group = args.substr(0, split);
                    std::string user = args.substr(split + 1);
                    SendMessage(sock, "UNMUTE|" + group + "|" + user);
                }
                else {
                    std::cout << "[错误]: /unmute 群组 用户名\n";
                }
            }
            else if (cmd == "muted") {
                if (!args.empty()) {
                    // 检查是否在该群中
                    if (std::find(clientState.joinedGroups.begin(),
                        clientState.joinedGroups.end(), args) != clientState.joinedGroups.end()) {
                        SendMessage(sock, "MUTED|" + args + "|-");
                    }
                    else {
                        std::cout << "[错误]: 您不在该群组中，无法查看禁言成员" << std::endl;
                    }
                }
                else {
                    std::cout << "[错误]: 格式为 /muted 群组名" << std::endl;
                }
            }
            else if (cmd == "members") {
                if (!args.empty()) {
                    // 检查用户是否在群组中
                    if (std::find(clientState.joinedGroups.begin(),
                        clientState.joinedGroups.end(), args) != clientState.joinedGroups.end()) {
                        SendMessage(sock, "MEMBERS|" + args + "|-");
                    }
                    else {
                        std::cout << "[错误]: 您不在该群组中，无法查看成员" << std::endl;
                    }
                }
                else {
                    std::cout << "[错误]: 请提供群组名，例如: /members groupname" << std::endl;
                }
            }
            else if (cmd == "join") {
                if (!args.empty()) {
                    SendMessage(sock, "JOIN|" + args + "|-");
                }
                else {
                    std::cout << "[错误]: 请提供群组名，例如: /join groupname" << std::endl;
                }
            }
            else if (cmd == "leave") {
                if (!args.empty()) {
                    SendMessage(sock, "LEAVE|" + args + "|-");
                }
                else {
                    std::cout << "[错误]: 请提供群组名，例如: /leave groupname" << std::endl;
                }
            }
            else if (cmd == "list") {
                SendMessage(sock, "LIST|USERS|-");
            }
            else if (cmd == "listgroups") {
                SendMessage(sock, "LIST|GROUPS|-");
            }
            else if (cmd == "private") {
                size_t split = args.find(' ');
                if (split != std::string::npos) {
                    std::string to = args.substr(0, split);
                    std::string msg = args.substr(split + 1);
                    SendMessage(sock, "PRIVATE|" + to + "|" + msg);
                }
                else {
                    std::cout << "[错误]: 请正确提供用户名和消息，例如: /private username message" << std::endl;
                }
            }
            else if (cmd == "group") {
                size_t split = args.find(' ');
                if (split != std::string::npos) {
                    std::string group = args.substr(0, split);
                    std::string msg = args.substr(split + 1);

                    // 检查用户是否在群组中
                    if (std::find(clientState.joinedGroups.begin(),
                        clientState.joinedGroups.end(), group) != clientState.joinedGroups.end()) {
                        SendMessage(sock, "GROUP|" + group + "|" + msg);
                    }
                    else {
                        std::cout << "[错误]: 您不在该群组中，无法发送消息" << std::endl;
                    }
                }
                else {
                    std::cout << "[错误]: 请正确提供群组名和消息，例如: /group groupname message" << std::endl;
                }
            }
            else if (cmd == "public") {
                if (!args.empty()) {
                    SendMessage(sock, "PUBLIC|-|" + args);
                }
                else {
                    std::cout << "[错误]: 请提供消息内容，例如: /public message" << std::endl;
                }
            }
            else if (cmd == "exit") {
                std::cout << "\n正在退出聊天客户端..." << std::endl;
                isRunning = false;
                break;
            }
            else if (cmd == "help" || cmd == "?") {
                PrintHelp();
            }
            else {
                std::cout << "未知命令，输入 /help 查看帮助" << std::endl;
            }
        }
        else {
            // 显示错误提示，不再自动发送消息
            std::cout << "[错误]: 消息必须以命令开头。使用 /public <消息> 发送公共消息，或输入 /help 查看所有命令。" << std::endl;
        }
    }
}

int main(int argc, char* argv[]) {
    WSADATA wsaData;
    SOCKET connectSock = INVALID_SOCKET;
    sockaddr_in serverAddr{};

    // 参数验证
    if (argc != 3) {
        std::cerr << "使用方法: " << argv[0] << " <服务器地址> <端口>" << std::endl;
        return 1;
    }

    // 初始化Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup 失败: " << WSAGetLastError() << std::endl;
        return 1;
    }

    // 创建套接字
    if ((connectSock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        std::cerr << "创建套接字失败: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    // 设置服务器地址
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[2]));
    if (inet_pton(AF_INET, argv[1], &serverAddr.sin_addr) <= 0) {
        std::cerr << "地址解析失败: " << argv[1] << std::endl;
        closesocket(connectSock);
        WSACleanup();
        return 1;
    }

    // 连接服务器
    if (connect(connectSock, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "连接服务器失败: " << WSAGetLastError() << std::endl;
        closesocket(connectSock);
        WSACleanup();
        return 1;
    }

    // 初始化DES加密模块
    if (des_init(0) == 0) { // 标准DES模式
        std::cerr << "DES加密模块初始化失败" << std::endl;
        closesocket(connectSock);
        WSACleanup();
        return 1;
    }
    des_set_key((char*)"mykey12"); // 设置8字节预共享密钥

    std::cout << "已安全连接到服务器 " << argv[1] << ":" << argv[2]
        << " [DES加密已启用]" << std::endl;

    // 启动接收线程
    std::thread receiverThread(MessageReceiver, connectSock);
    receiverThread.detach();

    // 处理用户输入
    HandleInput(connectSock);

    // 清理流程
    std::cout << "\n正在终止连接..." << std::endl;
    shutdown(connectSock, SD_SEND);  // 优雅关闭发送通道
    closesocket(connectSock);

    // 释放DES资源
    des_done();

    // 清理Winsock
    WSACleanup();

    std::cout << "安全连接已关闭，客户端已退出" << std::endl;
    return 0;
}