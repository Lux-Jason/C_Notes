﻿#include<stdio.h>
_Bool isDigitChar(char n);
